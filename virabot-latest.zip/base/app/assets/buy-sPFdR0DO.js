import { j as e, m as M, r as l, c as O, u as Ee } from "./vendor-cSKCWCw4.js";
import { c as L, a as F, u as U, L as K, f as ie } from "./index-TvERbYxt.js";
import { P as Pe } from "./page-transition-hN2mnFFY.js";
import { B as A, c as J } from "./button-C5RSbfXw.js";
import { u as Re, S as Ie } from "./use-media-3gyItSgI.js";
import { C as Me } from "./chevron-left-IhR4fNgD.js";
import { C as $, a as z, b as q, c as G } from "./card-N4SQnQPv.js";
import {
  c as Ae,
  a as ue,
  u as V,
  b as De,
  d as H,
  e as $e,
  f as ze,
} from "./ui-gYM7APLu.js";
import { I as oe } from "./input-2dfms11E.js";
import { C as Le } from "./circle-alert-RK8OBdj8.js";
/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Te = [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]],
  Ve = L("check", Te);
/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Be = [
    ["path", { d: "M21.801 10A10 10 0 1 1 17 3.335", key: "yps3ct" }],
    ["path", { d: "m9 11 3 3L22 4", key: "1pflzl" }],
  ],
  Oe = L("circle-check-big", Be);
/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const He = [
    ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
    ["polyline", { points: "12 6 12 12 16 14", key: "68esgv" }],
  ],
  me = L("clock", He);
/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Ke = [
    ["line", { x1: "22", x2: "2", y1: "12", y2: "12", key: "1y58io" }],
    [
      "path",
      {
        d: "M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",
        key: "oot6mr",
      },
    ],
    ["line", { x1: "6", x2: "6.01", y1: "16", y2: "16", key: "sgf278" }],
    ["line", { x1: "10", x2: "10.01", y1: "16", y2: "16", key: "1l4acy" }],
  ],
  Fe = L("hard-drive", Ke);
/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Ue = [
    [
      "rect",
      {
        width: "18",
        height: "11",
        x: "3",
        y: "11",
        rx: "2",
        ry: "2",
        key: "1w4ew1",
      },
    ],
    ["path", { d: "M7 11V7a5 5 0 0 1 10 0v4", key: "fwvmzm" }],
  ],
  We = L("lock", Ue);
/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Ye = [
    [
      "rect",
      {
        width: "20",
        height: "8",
        x: "2",
        y: "2",
        rx: "2",
        ry: "2",
        key: "ngkwjq",
      },
    ],
    [
      "rect",
      {
        width: "20",
        height: "8",
        x: "2",
        y: "14",
        rx: "2",
        ry: "2",
        key: "iecqi9",
      },
    ],
    ["line", { x1: "6", x2: "6.01", y1: "6", y2: "6", key: "16zg32" }],
    ["line", { x1: "6", x2: "6.01", y1: "18", y2: "18", key: "nzw8ys" }],
  ],
  le = L("server", Ye);
/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const qe = [
    ["circle", { cx: "8", cy: "21", r: "1", key: "jimo8o" }],
    ["circle", { cx: "19", cy: "21", r: "1", key: "13723u" }],
    [
      "path",
      {
        d: "M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12",
        key: "9zh506",
      },
    ],
  ],
  Ge = L("shopping-cart", qe);
/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Xe = [
    [
      "path",
      {
        d: "M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1",
        key: "18etb6",
      },
    ],
    ["path", { d: "M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4", key: "xoc0q4" }],
  ],
  Ze = L("wallet", Xe);
/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Qe = [
    [
      "path",
      {
        d: "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",
        key: "1xq2db",
      },
    ],
  ],
  Je = L("zap", Qe);
function et({
  steps: t,
  currentStep: s,
  skippedSteps: n,
  onStepClick: r,
  canGoBack: a,
  onGoBack: c,
}) {
  var i;
  return Re("(min-width: 768px)")
    ? e.jsx("div", {
        className: "w-full mb-8",
        children: e.jsx("div", {
          className: "flex items-center justify-between",
          children: t.map((u, f) => {
            const p = f + 1,
              d = p < s,
              h = p === s,
              m = n.has(p),
              b = !m && (p < s || (a && p <= s));
            return e.jsxs(
              "div",
              {
                className: "flex items-center flex-1",
                children: [
                  e.jsx("button", {
                    onClick: () => b && r(p),
                    disabled: !b,
                    className: `flex items-center justify-center w-10 h-10 rounded-full border-2 transition-all ${m ? "bg-neutral-300 dark:bg-neutral-600 border-neutral-300 dark:border-neutral-600 text-neutral-500 dark:text-neutral-400" : d ? "bg-primary border-primary text-primary-foreground" : h ? "border-primary text-primary bg-primary/10" : "border-neutral-300 dark:border-neutral-600 text-muted-foreground"} ${b && !m ? "cursor-pointer hover:scale-105" : "cursor-not-allowed"}`,
                    children: m
                      ? e.jsx(We, { className: "h-4 w-4" })
                      : d
                        ? e.jsx(Ve, { className: "h-5 w-5" })
                        : e.jsx("span", {
                            className: "text-sm font-medium",
                            children: p,
                          }),
                  }),
                  e.jsx("div", {
                    className: "mr-3 flex-1",
                    children: e.jsx("h3", {
                      className: `text-2xl font-bold ${m ? "text-neutral-400 dark:text-neutral-500 line-through" : h ? "text-primary" : d ? "text-foreground" : "text-muted-foreground"}`,
                      children: u.title,
                    }),
                  }),
                  f < t.length - 1 &&
                    e.jsx("div", {
                      className: `h-px flex-1 mx-4 ${d ? "bg-primary" : "bg-neutral-300 dark:bg-neutral-600"}`,
                    }),
                ],
              },
              u.id,
            );
          }),
        }),
      })
    : e.jsxs("div", {
        className: "w-full mb-8",
        children: [
          e.jsxs("div", {
            className: "flex items-center justify-between mb-4",
            children: [
              e.jsxs(A, {
                variant: "ghost",
                size: "sm",
                onClick: c,
                disabled: !a,
                className: "flex items-center gap-1",
                children: [e.jsx(Me, { className: "h-4 w-4" }), "قبلی"],
              }),
              e.jsxs("div", {
                className: "text-sm text-muted-foreground",
                children: [
                  "مرحله ",
                  s - [...n].filter((z) => z < s).length,
                  " از ",
                  t.length - n.size,
                ],
              }),
            ],
          }),
          e.jsx("div", {
            className: "bg-neutral-200 dark:bg-neutral-700 rounded-full h-2",
            children: e.jsx(M.div, {
              className: "bg-primary rounded-full h-2",
              initial: { width: 0 },
              animate: {
                width: `${((s - [...n].filter((z) => z < s).length) / (t.length - n.size)) * 100}%`,
              },
              transition: { duration: 0.3 },
            }),
          }),
          e.jsx("div", {
            className: "mt-2 text-center",
            children: e.jsx("h3", {
              className: `font-medium ${n.has(s) ? "line-through text-muted-foreground" : ""}`,
              children: (i = t[s - 1]) == null ? void 0 : i.title,
            }),
          }),
        ],
      });
}
async function tt(t, s) {
  try {
    return (
      await F.get("/miniapp", {
        params: { actions: "countries", user_id: t, category_id: s || 0 },
      })
    ).data.obj;
  } catch (s) {
    return (console.error("Error fetching countries:", s), []);
  }
}
async function st(t) {
  try {
    return (
      await F.get("/miniapp", {
        params: { actions: "categories", user_id: t },
      })
    ).data.obj;
  } catch (n) {
    return (console.error("Error fetching categories:", n), []);
  }
}
async function nt(t, s, n) {
  try {
    return (
      await F.get("/miniapp", {
        params: {
          actions: "time_ranges",
          user_id: t,
          country_id: s,
          category_id: n,
        },
      })
    ).data.obj;
  } catch (r) {
    return (console.error("Error fetching time ranges:", r), []);
  }
}
async function rt(t, s, n, r) {
  try {
    return (
      await F.get("/miniapp", {
        params: {
          actions: "services",
          user_id: t,
          country_id: s,
          category_id: n,
          time_range_day: r,
        },
      })
    ).data.obj;
  } catch (a) {
    return (console.error("Error fetching services:", a), []);
  }
}
async function at(t, s, n, r, a) {
  try {
    return (
      await F.get("/miniapp", {
        params: {
          actions: "custom_price",
          user_id: t,
          country_id: s,
          category_id: n,
          traffic_gb: r,
          time_days: a,
        },
      })
    ).data.obj;
  } catch (c) {
    return (console.error("Error fetching custom service price:", c), null);
  }
}
async function it(t, s) {
  try {
    return (await F.post("/miniapp", { actions: "purchase", user_id: t, ...s }))
      .data;
  } catch (n) {
    throw (console.error("Error purchasing service:", n), n);
  }
}
function ot({
  selectedCountry: t,
  selectedCategory: sc,
  onCountrySelect: s,
  onNext: n,
  onStepSkipped: r,
}) {
  const { user: a } = U(),
    [c, o] = l.useState([]),
    [i, u] = l.useState(!0),
    [f, p] = l.useState(null);
  return (
    l.useEffect(() => {
      (async () => {
        if (!(a != null && a.id)) return;
        u(!0);
        const h = await tt(a.id, sc == null ? void 0 : sc.id);
        if ((o(h), u(!1), !h)) {
          (u(!1), p("خطا در بارگذاری سرویس‌ها"));
          return;
        }
        h.length === 1 && (s(h[0]), r());
      })();
    }, [a == null ? void 0 : a.id, sc == null ? void 0 : sc.id]),
    i
      ? e.jsx("div", {
          className: "flex items-center justify-center py-12",
          children: e.jsx(K, {
            className: "h-8 w-8 animate-spin text-primary",
          }),
        })
      : f
        ? e.jsx("div", {
            className: "text-center text-red-500",
            children: e.jsx("p", { children: f }),
          })
        : c.length === 0
          ? e.jsx("div", {
              className: "text-center text-muted-foreground",
              children: e.jsx("p", {
                children: "هیچ سرویسی برای انتخاب وجود ندارد",
              }),
            })
          : e.jsxs("div", {
              className: "space-y-6",
              children: [
                e.jsxs("div", {
                  className: "text-center",
                  children: [
                    e.jsx("h2", {
                      className: "text-2xl font-bold mb-2",
                      children: "انتخاب سرویس",
                    }),
                    e.jsx("p", {
                      className: "text-muted-foreground",
                      children: "سرویس مورد نظر خود را انتخاب کنید",
                    }),
                  ],
                }),
                e.jsx("div", {
                  className:
                    "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
                  children: c.map((d, h) =>
                    e.jsx(
                      M.div,
                      {
                        initial: { opacity: 0, y: 20 },
                        animate: { opacity: 1, y: 0 },
                        transition: { duration: 0.3, delay: h * 0.1 },
                        children: e.jsx($, {
                          className: `cursor-pointer transition-all hover:shadow-md ${(t == null ? void 0 : t.id) === d.id ? "ring-2 ring-primary bg-primary/5" : "hover:bg-accent/50"}`,
                          onClick: () => s(d),
                          children: e.jsx(z, {
                            className: "p-4 text-center",
                            children: e.jsx("h3", {
                              className: "font-medium",
                              children: d.name,
                            }),
                          }),
                        }),
                      },
                      d.id,
                    ),
                  ),
                }),
                t &&
                  e.jsxs(M.div, {
                    initial: { opacity: 0, y: 20 },
                    animate: { opacity: 1, y: 0 },
                    className:
                      "fixed bottom-24 left-0 right-0 flex justify-around z-10 bg-neutral-200 dark:bg-neutral-700 py-3 my-2 rounded-xl mx-5 items-center",
                    children: [
                      e.jsxs("p", {
                        className:
                          "text-center text-sm text-muted-foreground flex flex-col",
                        children: [
                          e.jsx("span", {
                            className:
                              "text-xs text-foreground font-semibold mb-1",
                            children: "سرویس انتخاب شده:",
                          }),
                          e.jsx("span", {
                            className: "font-semibold",
                            children: t.name,
                          }),
                        ],
                      }),
                      e.jsx(A, {
                        onClick: n,
                        size: "lg",
                        className:
                          "px-12 shadow-lg hover:shadow-xl transition-shadow",
                        children: "ادامه",
                      }),
                    ],
                  }),
              ],
            })
  );
}
function lt({
  selectedCategory: s,
  onCategorySelect: n,
  onNext: r,
  onStepSkipped: a,
}) {
  const { user: c } = U(),
    [o, i] = l.useState([]),
    [u, f] = l.useState(!0),
    [p, d] = l.useState(null);
  return (
    l.useEffect(() => {
      (async () => {
        if (!(c != null && c.id)) return;
        f(!0);
        const m = await st(c.id);
        if (!m) {
          (f(!1), d("خطا در بارگذاری دسته بندی‌ها"));
          return;
        }
        (i(m),
          f(!1),
          m.length === 0 &&
            (a(), n({ id: "0", name: "بدون دسته بندی", description: "" })));
      })();
    }, [c == null ? void 0 : c.id]),
    u
      ? e.jsx("div", {
          className: "flex items-center justify-center py-12",
          children: e.jsx(K, {
            className: "h-8 w-8 animate-spin text-primary",
          }),
        })
      : p
        ? e.jsx("div", { className: "text-center text-red-500", children: p })
        : e.jsxs("div", {
            className: "space-y-6",
            children: [
              e.jsx("div", {
                className: "text-center",
                children: e.jsx("p", {
                  className: "text-muted-foreground",
                  children: "دسته‌بندی مورد نظر خود را انتخاب کنید",
                }),
              }),
              e.jsx("div", {
                className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                children: o.map((h, m) =>
                  e.jsx(
                    M.div,
                    {
                      initial: { opacity: 0, y: 20 },
                      animate: { opacity: 1, y: 0 },
                      transition: { duration: 0.3, delay: m * 0.1 },
                      children: e.jsx($, {
                        className: `cursor-pointer transition-all hover:shadow-md ${(s == null ? void 0 : s.id) === h.id ? "ring-2 ring-primary bg-primary/5" : "hover:bg-accent/50"}`,
                        onClick: () => n(h),
                        children: e.jsx(z, {
                          className: "p-4 text-center",
                          children: e.jsx("h3", {
                            className: "font-medium",
                            children: h.name,
                          }),
                        }),
                      }),
                    },
                    h.id,
                  ),
                ),
              }),
              s &&
                e.jsxs(M.div, {
                  initial: { opacity: 0, y: 20 },
                  animate: { opacity: 1, y: 0 },
                  className:
                    "fixed bottom-24 left-0 right-0 flex justify-around z-10 bg-neutral-200 dark:bg-neutral-700 py-3 my-2 rounded-xl mx-5 items-center",
                  children: [
                    e.jsxs("p", {
                      className:
                        "text-center text-sm text-muted-foreground flex flex-col",
                      children: [
                        e.jsx("span", {
                          className:
                            "text-xs text-foreground font-semibold mb-1",
                          children: "دسته بندی انتخاب شده:",
                        }),
                        e.jsx("span", {
                          className: "font-semibold",
                          children: s.name,
                        }),
                      ],
                    }),
                    e.jsx(A, {
                      onClick: r,
                      size: "lg",
                      className:
                        "px-12 shadow-lg hover:shadow-xl transition-shadow",
                      children: "ادامه",
                    }),
                  ],
                }),
            ],
          })
  );
}
function ct({
  selectedCountry: t,
  selectedCategory: s,
  selectedTimeRange: n,
  onTimeRangeSelect: r,
  onNext: a,
  onStepSkipped: c,
}) {
  const { user: o } = U(),
    [i, u] = l.useState([]),
    [f, p] = l.useState(!0),
    [d, h] = l.useState(null);
  return (
    l.useEffect(() => {
      (async () => {
        if (!(o != null && o.id)) return;
        p(!0);
        const b = await nt(o.id, t.id, s.id);
        if (!b) {
          (p(!1), h("خطا در بارگذاری مدت زمان‌ها"));
          return;
        }
        (u(b),
          p(!1),
          b.length === 0 && (c(), r({ day: 0, name: "بدون مدت زمان" })));
      })();
    }, [o == null ? void 0 : o.id, t.id, s.id]),
    f
      ? e.jsx("div", {
          className: "flex items-center justify-center py-12",
          children: e.jsx(K, {
            className: "h-8 w-8 animate-spin text-primary",
          }),
        })
      : d
        ? e.jsx("div", { className: "text-center text-red-500", children: d })
        : e.jsxs("div", {
            className: "space-y-6",
            children: [
              e.jsxs("div", {
                className: "text-center",
                children: [
                  e.jsx("h2", {
                    className: "text-2xl font-bold mb-2",
                    children: "انتخاب مدت زمان",
                  }),
                  e.jsx("p", {
                    className: "text-muted-foreground",
                    children: "مدت زمان سرویس مورد نظر خود را انتخاب کنید",
                  }),
                ],
              }),
              e.jsx("div", {
                className:
                  "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4",
                children: i.map((m, b) =>
                  e.jsx(
                    M.div,
                    {
                      initial: { opacity: 0, y: 20 },
                      animate: { opacity: 1, y: 0 },
                      transition: { duration: 0.3, delay: b * 0.1 },
                      children: e.jsx($, {
                        className: `cursor-pointer h-12/12 transition-all hover:shadow-md ${(n == null ? void 0 : n.day) === m.day && (n == null ? void 0 : n.name) === m.name ? "ring-2 ring-primary bg-primary/5" : "hover:bg-accent/50"}`,
                        onClick: () => r(m),
                        children: e.jsxs(z, {
                          className: "p-4 text-center",
                          children: [
                            e.jsx(me, {
                              className: "h-6 w-6 mx-auto mb-2 text-primary",
                            }),
                            e.jsx("h3", {
                              className: "font-medium",
                              children: m.name,
                            }),
                            m.day > 0 &&
                              e.jsxs("p", {
                                className: "text-sm text-muted-foreground",
                                children: [m.day, " روز"],
                              }),
                          ],
                        }),
                      }),
                    },
                    `${m.name}-${m.day}`,
                  ),
                ),
              }),
              n &&
                e.jsxs(M.div, {
                  initial: { opacity: 0, y: 20 },
                  animate: { opacity: 1, y: 0 },
                  className:
                    "fixed bottom-24 left-0 right-0 flex justify-around z-10 bg-neutral-200 dark:bg-neutral-700 py-3 my-2 rounded-xl mx-5 items-center",
                  children: [
                    e.jsxs("p", {
                      className:
                        "text-center text-sm text-muted-foreground flex flex-col",
                      children: [
                        e.jsx("span", {
                          className:
                            "text-xs text-foreground font-semibold mb-1",
                          children: "مدت زمان انتخاب شده:",
                        }),
                        e.jsxs("span", {
                          className: "font-semibold",
                          children: [
                            n.name,
                            " ",
                            n.day > 0 && `(${n.day} روز)`,
                          ],
                        }),
                      ],
                    }),
                    e.jsx(A, {
                      onClick: a,
                      size: "lg",
                      className:
                        "px-12 shadow-lg hover:shadow-xl transition-shadow",
                      children: "ادامه",
                    }),
                  ],
                }),
            ],
          })
  );
}
function xe(t, [s, n]) {
  return Math.min(n, Math.max(s, t));
}
function dt(t) {
  const s = l.useRef({ value: t, previous: t });
  return l.useMemo(
    () => (
      s.current.value !== t &&
        ((s.current.previous = s.current.value), (s.current.value = t)),
      s.current.previous
    ),
    [t],
  );
}
function ee(t) {
  const s = ut(t),
    n = l.forwardRef((r, a) => {
      const { children: c, ...o } = r,
        i = l.Children.toArray(c),
        u = i.find(xt);
      if (u) {
        const f = u.props.children,
          p = i.map((d) =>
            d === u
              ? l.Children.count(f) > 1
                ? l.Children.only(null)
                : l.isValidElement(f)
                  ? f.props.children
                  : null
              : d,
          );
        return e.jsx(s, {
          ...o,
          ref: a,
          children: l.isValidElement(f) ? l.cloneElement(f, void 0, p) : null,
        });
      }
      return e.jsx(s, { ...o, ref: a, children: c });
    });
  return ((n.displayName = `${t}.Slot`), n);
}
function ut(t) {
  const s = l.forwardRef((n, r) => {
    const { children: a, ...c } = n;
    if (l.isValidElement(a)) {
      const o = ht(a),
        i = ft(c, a.props);
      return (
        a.type !== l.Fragment && (i.ref = r ? Ae(r, o) : o),
        l.cloneElement(a, i)
      );
    }
    return l.Children.count(a) > 1 ? l.Children.only(null) : null;
  });
  return ((s.displayName = `${t}.SlotClone`), s);
}
var mt = Symbol("radix.slottable");
function xt(t) {
  return (
    l.isValidElement(t) &&
    typeof t.type == "function" &&
    "__radixId" in t.type &&
    t.type.__radixId === mt
  );
}
function ft(t, s) {
  const n = { ...s };
  for (const r in s) {
    const a = t[r],
      c = s[r];
    /^on[A-Z]/.test(r)
      ? a && c
        ? (n[r] = (...i) => {
            const u = c(...i);
            return (a(...i), u);
          })
        : a && (n[r] = a)
      : r === "style"
        ? (n[r] = { ...a, ...c })
        : r === "className" && (n[r] = [a, c].filter(Boolean).join(" "));
  }
  return { ...t, ...n };
}
function ht(t) {
  var r, a;
  let s =
      (r = Object.getOwnPropertyDescriptor(t.props, "ref")) == null
        ? void 0
        : r.get,
    n = s && "isReactWarning" in s && s.isReactWarning;
  return n
    ? t.ref
    : ((s =
        (a = Object.getOwnPropertyDescriptor(t, "ref")) == null
          ? void 0
          : a.get),
      (n = s && "isReactWarning" in s && s.isReactWarning),
      n ? t.props.ref : t.props.ref || t.ref);
}
var pt = [
    "a",
    "button",
    "div",
    "form",
    "h2",
    "h3",
    "img",
    "input",
    "label",
    "li",
    "nav",
    "ol",
    "p",
    "select",
    "span",
    "svg",
    "ul",
  ],
  X = pt.reduce((t, s) => {
    const n = ee(`Primitive.${s}`),
      r = l.forwardRef((a, c) => {
        const { asChild: o, ...i } = a,
          u = o ? n : s;
        return (
          typeof window < "u" && (window[Symbol.for("radix-ui")] = !0),
          e.jsx(u, { ...i, ref: c })
        );
      });
    return ((r.displayName = `Primitive.${s}`), { ...t, [s]: r });
  }, {});
function gt(t) {
  const s = t + "CollectionProvider",
    [n, r] = ue(s),
    [a, c] = n(s, { collectionRef: { current: null }, itemMap: new Map() }),
    o = (g) => {
      const { scope: j, children: x } = g,
        S = O.useRef(null),
        w = O.useRef(new Map()).current;
      return e.jsx(a, { scope: j, itemMap: w, collectionRef: S, children: x });
    };
  o.displayName = s;
  const i = t + "CollectionSlot",
    u = ee(i),
    f = O.forwardRef((g, j) => {
      const { scope: x, children: S } = g,
        w = c(i, x),
        N = V(j, w.collectionRef);
      return e.jsx(u, { ref: N, children: S });
    });
  f.displayName = i;
  const p = t + "CollectionItemSlot",
    d = "data-radix-collection-item",
    h = ee(p),
    m = O.forwardRef((g, j) => {
      const { scope: x, children: S, ...w } = g,
        N = O.useRef(null),
        R = V(j, N),
        k = c(p, x);
      return (
        O.useEffect(
          () => (
            k.itemMap.set(N, { ref: N, ...w }),
            () => void k.itemMap.delete(N)
          ),
        ),
        e.jsx(h, { [d]: "", ref: R, children: S })
      );
    });
  m.displayName = p;
  function b(g) {
    const j = c(t + "CollectionConsumer", g);
    return O.useCallback(() => {
      const S = j.collectionRef.current;
      if (!S) return [];
      const w = Array.from(S.querySelectorAll(`[${d}]`));
      return Array.from(j.itemMap.values()).sort(
        (k, v) => w.indexOf(k.ref.current) - w.indexOf(v.ref.current),
      );
    }, [j.collectionRef, j.itemMap]);
  }
  return [{ Provider: o, Slot: f, ItemSlot: m }, b, r];
}
var fe = ["PageUp", "PageDown"],
  he = ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"],
  pe = {
    "from-left": ["Home", "PageDown", "ArrowDown", "ArrowLeft"],
    "from-right": ["Home", "PageDown", "ArrowDown", "ArrowRight"],
    "from-bottom": ["Home", "PageDown", "ArrowDown", "ArrowLeft"],
    "from-top": ["Home", "PageDown", "ArrowUp", "ArrowLeft"],
  },
  W = "Slider",
  [te, jt, yt] = gt(W),
  [ge, Xt] = ue(W, [yt]),
  [bt, Q] = ge(W),
  je = l.forwardRef((t, s) => {
    const {
        name: n,
        min: r = 0,
        max: a = 100,
        step: c = 1,
        orientation: o = "horizontal",
        disabled: i = !1,
        minStepsBetweenThumbs: u = 0,
        defaultValue: f = [r],
        value: p,
        onValueChange: d = () => {},
        onValueCommit: h = () => {},
        inverted: m = !1,
        form: b,
        ...g
      } = t,
      j = l.useRef(new Set()),
      x = l.useRef(0),
      w = o === "horizontal" ? Nt : vt,
      [N = [], R] = De({
        prop: p,
        defaultProp: f,
        onChange: (E) => {
          var T;
          ((T = [...j.current][x.current]) == null || T.focus(), d(E));
        },
      }),
      k = l.useRef(N);
    function v(E) {
      const D = kt(N, E);
      I(E, D);
    }
    function C(E) {
      I(E, x.current);
    }
    function _() {
      const E = k.current[x.current];
      N[x.current] !== E && h(N);
    }
    function I(E, D, { commit: T } = { commit: !1 }) {
      const Z = It(c),
        Y = Mt(Math.round((E - r) / c) * c + r, Z),
        B = xe(Y, [r, a]);
      R((y = []) => {
        const P = _t(y, B, D);
        if (Rt(P, u * c)) {
          x.current = P.indexOf(B);
          const ae = String(P) !== String(y);
          return (ae && T && h(P), ae ? P : y);
        } else return y;
      });
    }
    return e.jsx(bt, {
      scope: t.__scopeSlider,
      name: n,
      disabled: i,
      min: r,
      max: a,
      valueIndexToChangeRef: x,
      thumbs: j.current,
      values: N,
      orientation: o,
      form: b,
      children: e.jsx(te.Provider, {
        scope: t.__scopeSlider,
        children: e.jsx(te.Slot, {
          scope: t.__scopeSlider,
          children: e.jsx(w, {
            "aria-disabled": i,
            "data-disabled": i ? "" : void 0,
            ...g,
            ref: s,
            onPointerDown: H(g.onPointerDown, () => {
              i || (k.current = N);
            }),
            min: r,
            max: a,
            inverted: m,
            onSlideStart: i ? void 0 : v,
            onSlideMove: i ? void 0 : C,
            onSlideEnd: i ? void 0 : _,
            onHomeKeyDown: () => !i && I(r, 0, { commit: !0 }),
            onEndKeyDown: () => !i && I(a, N.length - 1, { commit: !0 }),
            onStepKeyDown: ({ event: E, direction: D }) => {
              if (!i) {
                const Y =
                    fe.includes(E.key) || (E.shiftKey && he.includes(E.key))
                      ? 10
                      : 1,
                  B = x.current,
                  y = N[B],
                  P = c * Y * D;
                I(y + P, B, { commit: !0 });
              }
            },
          }),
        }),
      }),
    });
  });
je.displayName = W;
var [ye, be] = ge(W, {
    startEdge: "left",
    endEdge: "right",
    size: "width",
    direction: 1,
  }),
  Nt = l.forwardRef((t, s) => {
    const {
        min: n,
        max: r,
        dir: a,
        inverted: c,
        onSlideStart: o,
        onSlideMove: i,
        onSlideEnd: u,
        onStepKeyDown: f,
        ...p
      } = t,
      [d, h] = l.useState(null),
      m = V(s, (w) => h(w)),
      b = l.useRef(void 0),
      g = $e(a),
      j = g === "ltr",
      x = (j && !c) || (!j && c);
    function S(w) {
      const N = b.current || d.getBoundingClientRect(),
        R = [0, N.width],
        v = re(R, x ? [n, r] : [r, n]);
      return ((b.current = N), v(w - N.left));
    }
    return e.jsx(ye, {
      scope: t.__scopeSlider,
      startEdge: x ? "left" : "right",
      endEdge: x ? "right" : "left",
      direction: x ? 1 : -1,
      size: "width",
      children: e.jsx(Ne, {
        dir: g,
        "data-orientation": "horizontal",
        ...p,
        ref: m,
        style: {
          ...p.style,
          "--radix-slider-thumb-transform": "translateX(-50%)",
        },
        onSlideStart: (w) => {
          const N = S(w.clientX);
          o == null || o(N);
        },
        onSlideMove: (w) => {
          const N = S(w.clientX);
          i == null || i(N);
        },
        onSlideEnd: () => {
          ((b.current = void 0), u == null || u());
        },
        onStepKeyDown: (w) => {
          const R = pe[x ? "from-left" : "from-right"].includes(w.key);
          f == null || f({ event: w, direction: R ? -1 : 1 });
        },
      }),
    });
  }),
  vt = l.forwardRef((t, s) => {
    const {
        min: n,
        max: r,
        inverted: a,
        onSlideStart: c,
        onSlideMove: o,
        onSlideEnd: i,
        onStepKeyDown: u,
        ...f
      } = t,
      p = l.useRef(null),
      d = V(s, p),
      h = l.useRef(void 0),
      m = !a;
    function b(g) {
      const j = h.current || p.current.getBoundingClientRect(),
        x = [0, j.height],
        w = re(x, m ? [r, n] : [n, r]);
      return ((h.current = j), w(g - j.top));
    }
    return e.jsx(ye, {
      scope: t.__scopeSlider,
      startEdge: m ? "bottom" : "top",
      endEdge: m ? "top" : "bottom",
      size: "height",
      direction: m ? 1 : -1,
      children: e.jsx(Ne, {
        "data-orientation": "vertical",
        ...f,
        ref: d,
        style: {
          ...f.style,
          "--radix-slider-thumb-transform": "translateY(50%)",
        },
        onSlideStart: (g) => {
          const j = b(g.clientY);
          c == null || c(j);
        },
        onSlideMove: (g) => {
          const j = b(g.clientY);
          o == null || o(j);
        },
        onSlideEnd: () => {
          ((h.current = void 0), i == null || i());
        },
        onStepKeyDown: (g) => {
          const x = pe[m ? "from-bottom" : "from-top"].includes(g.key);
          u == null || u({ event: g, direction: x ? -1 : 1 });
        },
      }),
    });
  }),
  Ne = l.forwardRef((t, s) => {
    const {
        __scopeSlider: n,
        onSlideStart: r,
        onSlideMove: a,
        onSlideEnd: c,
        onHomeKeyDown: o,
        onEndKeyDown: i,
        onStepKeyDown: u,
        ...f
      } = t,
      p = Q(W, n);
    return e.jsx(X.span, {
      ...f,
      ref: s,
      onKeyDown: H(t.onKeyDown, (d) => {
        d.key === "Home"
          ? (o(d), d.preventDefault())
          : d.key === "End"
            ? (i(d), d.preventDefault())
            : fe.concat(he).includes(d.key) && (u(d), d.preventDefault());
      }),
      onPointerDown: H(t.onPointerDown, (d) => {
        const h = d.target;
        (h.setPointerCapture(d.pointerId),
          d.preventDefault(),
          p.thumbs.has(h) ? h.focus() : r(d));
      }),
      onPointerMove: H(t.onPointerMove, (d) => {
        d.target.hasPointerCapture(d.pointerId) && a(d);
      }),
      onPointerUp: H(t.onPointerUp, (d) => {
        const h = d.target;
        h.hasPointerCapture(d.pointerId) &&
          (h.releasePointerCapture(d.pointerId), c(d));
      }),
    });
  }),
  ve = "SliderTrack",
  we = l.forwardRef((t, s) => {
    const { __scopeSlider: n, ...r } = t,
      a = Q(ve, n);
    return e.jsx(X.span, {
      "data-disabled": a.disabled ? "" : void 0,
      "data-orientation": a.orientation,
      ...r,
      ref: s,
    });
  });
we.displayName = ve;
var se = "SliderRange",
  Se = l.forwardRef((t, s) => {
    const { __scopeSlider: n, ...r } = t,
      a = Q(se, n),
      c = be(se, n),
      o = l.useRef(null),
      i = V(s, o),
      u = a.values.length,
      f = a.values.map((h) => ke(h, a.min, a.max)),
      p = u > 1 ? Math.min(...f) : 0,
      d = 100 - Math.max(...f);
    return e.jsx(X.span, {
      "data-orientation": a.orientation,
      "data-disabled": a.disabled ? "" : void 0,
      ...r,
      ref: i,
      style: { ...t.style, [c.startEdge]: p + "%", [c.endEdge]: d + "%" },
    });
  });
Se.displayName = se;
var ne = "SliderThumb",
  _e = l.forwardRef((t, s) => {
    const n = jt(t.__scopeSlider),
      [r, a] = l.useState(null),
      c = V(s, (i) => a(i)),
      o = l.useMemo(
        () => (r ? n().findIndex((i) => i.ref.current === r) : -1),
        [n, r],
      );
    return e.jsx(wt, { ...t, ref: c, index: o });
  }),
  wt = l.forwardRef((t, s) => {
    const { __scopeSlider: n, index: r, name: a, ...c } = t,
      o = Q(ne, n),
      i = be(ne, n),
      [u, f] = l.useState(null),
      p = V(s, (S) => f(S)),
      d = u ? o.form || !!u.closest("form") : !0,
      h = ze(u),
      m = o.values[r],
      b = m === void 0 ? 0 : ke(m, o.min, o.max),
      g = Ct(r, o.values.length),
      j = h == null ? void 0 : h[i.size],
      x = j ? Et(j, b, i.direction) : 0;
    return (
      l.useEffect(() => {
        if (u)
          return (
            o.thumbs.add(u),
            () => {
              o.thumbs.delete(u);
            }
          );
      }, [u, o.thumbs]),
      e.jsxs("span", {
        style: {
          transform: "var(--radix-slider-thumb-transform)",
          position: "absolute",
          [i.startEdge]: `calc(${b}% + ${x}px)`,
        },
        children: [
          e.jsx(te.ItemSlot, {
            scope: t.__scopeSlider,
            children: e.jsx(X.span, {
              role: "slider",
              "aria-label": t["aria-label"] || g,
              "aria-valuemin": o.min,
              "aria-valuenow": m,
              "aria-valuemax": o.max,
              "aria-orientation": o.orientation,
              "data-orientation": o.orientation,
              "data-disabled": o.disabled ? "" : void 0,
              tabIndex: o.disabled ? void 0 : 0,
              ...c,
              ref: p,
              style: m === void 0 ? { display: "none" } : t.style,
              onFocus: H(t.onFocus, () => {
                o.valueIndexToChangeRef.current = r;
              }),
            }),
          }),
          d &&
            e.jsx(
              Ce,
              {
                name:
                  a ??
                  (o.name
                    ? o.name + (o.values.length > 1 ? "[]" : "")
                    : void 0),
                form: o.form,
                value: m,
              },
              r,
            ),
        ],
      })
    );
  });
_e.displayName = ne;
var St = "RadioBubbleInput",
  Ce = l.forwardRef(({ __scopeSlider: t, value: s, ...n }, r) => {
    const a = l.useRef(null),
      c = V(a, r),
      o = dt(s);
    return (
      l.useEffect(() => {
        const i = a.current;
        if (!i) return;
        const u = window.HTMLInputElement.prototype,
          p = Object.getOwnPropertyDescriptor(u, "value").set;
        if (o !== s && p) {
          const d = new Event("input", { bubbles: !0 });
          (p.call(i, s), i.dispatchEvent(d));
        }
      }, [o, s]),
      e.jsx(X.input, {
        style: { display: "none" },
        ...n,
        ref: c,
        defaultValue: s,
      })
    );
  });
Ce.displayName = St;
function _t(t = [], s, n) {
  const r = [...t];
  return ((r[n] = s), r.sort((a, c) => a - c));
}
function ke(t, s, n) {
  const c = (100 / (n - s)) * (t - s);
  return xe(c, [0, 100]);
}
function Ct(t, s) {
  return s > 2
    ? `Value ${t + 1} of ${s}`
    : s === 2
      ? ["Minimum", "Maximum"][t]
      : void 0;
}
function kt(t, s) {
  if (t.length === 1) return 0;
  const n = t.map((a) => Math.abs(a - s)),
    r = Math.min(...n);
  return n.indexOf(r);
}
function Et(t, s, n) {
  const r = t / 2,
    c = re([0, 50], [0, r]);
  return (r - c(s) * n) * n;
}
function Pt(t) {
  return t.slice(0, -1).map((s, n) => t[n + 1] - s);
}
function Rt(t, s) {
  if (s > 0) {
    const n = Pt(t);
    return Math.min(...n) >= s;
  }
  return !0;
}
function re(t, s) {
  return (n) => {
    if (t[0] === t[1] || s[0] === s[1]) return s[0];
    const r = (s[1] - s[0]) / (t[1] - t[0]);
    return s[0] + r * (n - t[0]);
  };
}
function It(t) {
  return (String(t).split(".")[1] || "").length;
}
function Mt(t, s) {
  const n = Math.pow(10, s);
  return Math.round(t * n) / n;
}
var At = je,
  Dt = we,
  $t = Se,
  zt = _e;
function ce({
  className: t,
  defaultValue: s,
  value: n,
  min: r = 0,
  max: a = 100,
  ...c
}) {
  const o = l.useMemo(
    () => (Array.isArray(n) ? n : Array.isArray(s) ? s : [r, a]),
    [n, s, r, a],
  );
  return e.jsxs(At, {
    "data-slot": "slider",
    defaultValue: s,
    value: n,
    min: r,
    max: a,
    className: J(
      "relative flex w-full touch-none items-center select-none data-[disabled]:opacity-50 data-[orientation=vertical]:h-full data-[orientation=vertical]:min-h-44 data-[orientation=vertical]:w-auto data-[orientation=vertical]:flex-col",
      t,
    ),
    ...c,
    children: [
      e.jsx(Dt, {
        "data-slot": "slider-track",
        className: J(
          "bg-muted relative grow overflow-hidden rounded-full data-[orientation=horizontal]:h-1.5 data-[orientation=horizontal]:w-full data-[orientation=vertical]:h-full data-[orientation=vertical]:w-1.5",
        ),
        children: e.jsx($t, {
          "data-slot": "slider-range",
          className: J(
            "bg-primary absolute data-[orientation=horizontal]:h-full data-[orientation=vertical]:w-full",
          ),
        }),
      }),
      Array.from({ length: o.length }, (i, u) =>
        e.jsx(
          zt,
          {
            "data-slot": "slider-thumb",
            className:
              "border-primary bg-background ring-ring/50 block size-4 shrink-0 rounded-full border shadow-sm transition-[color,box-shadow] hover:ring-4 focus-visible:ring-4 focus-visible:outline-hidden disabled:pointer-events-none disabled:opacity-50",
          },
          u,
        ),
      ),
    ],
  });
}
function Lt({
  selectedCountry: t,
  selectedCategory: s,
  selectedTimeRange: n,
  selectedService: r,
  customService: a,
  onServiceSelect: c,
  onCustomServiceSelect: o,
  onNext: i,
}) {
  var k;
  const { user: u } = U(),
    [f, p] = l.useState([]),
    [d, h] = l.useState(!0),
    [m, b] = l.useState([50]),
    [g, j] = l.useState([30]),
    [x, S] = l.useState(null),
    [w, N] = l.useState(!1);
  (l.useEffect(() => {
    (async () => {
      if (!(u != null && u.id)) return;
      h(!0);
      const C = await rt(u.id, t.id, s.id, n.day);
      (p(C), h(!1));
    })();
  }, [u == null ? void 0 : u.id, t.id, s.id, n.day]),
    l.useEffect(() => {
      const C = setTimeout(async () => {
        if (!(u != null && u.id)) return;
        N(!0);
        const _ = await at(u.id, t.id, s.id, m[0], g[0]);
        if (!_) {
          (S(null), N(!1));
          return;
        }
        (S(_), N(!1));
      }, 500);
      return () => clearTimeout(C);
    }, [u == null ? void 0 : u.id, t.id, s.id, m, g]));
  const R = () => {
    x && o({ traffic_gb: m[0], time_days: g[0], price: x.price });
  };
  return (
    l.useEffect(() => {
      x && a && o({ traffic_gb: m[0], time_days: g[0], price: x.price });
    }, [x]),
    d
      ? e.jsx("div", {
          className: "flex items-center justify-center py-12",
          children: e.jsx(K, {
            className: "h-8 w-8 animate-spin text-primary",
          }),
        })
      : e.jsxs("div", {
          className: "space-y-6",
          children: [
            e.jsxs("div", {
              className: "text-center",
              children: [
                e.jsx("h2", {
                  className: "text-2xl font-bold mb-2",
                  children: "انتخاب سرویس",
                }),
                e.jsx("p", {
                  className: "text-muted-foreground",
                  children:
                    "سرویس مورد نظر خود را انتخاب کنید یا سرویس سفارشی بسازید",
                }),
              ],
            }),
            f.length > 0
              ? e.jsxs("div", {
                  children: [
                    e.jsx("h3", {
                      className: "text-lg font-semibold mb-4",
                      children: "سرویس‌های آماده",
                    }),
                    e.jsx("div", {
                      className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                      children: f.map((v, C) => {
                        var _;
                        return e.jsx(
                          M.div,
                          {
                            initial: { opacity: 0, y: 20 },
                            animate: { opacity: 1, y: 0 },
                            transition: { duration: 0.3, delay: C * 0.1 },
                            children: e.jsxs($, {
                              className: `cursor-pointer transition-all hover:shadow-md ${(r == null ? void 0 : r.id) === v.id ? "ring-2 ring-primary bg-primary/5" : "hover:bg-accent/50"}`,
                              onClick: () => c(v),
                              children: [
                                e.jsx(q, {
                                  className: "pb-2",
                                  children: e.jsxs(G, {
                                    className:
                                      "text-lg flex items-center gap-2",
                                    children: [
                                      e.jsx(le, { className: "h-5 w-5" }),
                                      v.name,
                                    ],
                                  }),
                                }),
                                e.jsx(z, {
                                  children: e.jsxs("div", {
                                    className: "space-y-2",
                                    children: [
                                      v.traffic_gb &&
                                        e.jsxs("div", {
                                          className:
                                            "flex items-center gap-2 text-sm",
                                          children: [
                                            e.jsx(Fe, {
                                              className:
                                                "h-4 w-4 text-muted-foreground",
                                            }),
                                            e.jsxs("span", {
                                              children: [
                                                v.traffic_gb,
                                                " گیگابایت",
                                              ],
                                            }),
                                          ],
                                        }),
                                      typeof v.time_days == "number" &&
                                        e.jsxs("div", {
                                          className:
                                            "flex items-center gap-2 text-sm",
                                          children: [
                                            e.jsx(me, {
                                              className:
                                                "h-4 w-4 text-muted-foreground",
                                            }),
                                            e.jsx("span", {
                                              children:
                                                v.time_days === 0
                                                  ? "نامحدود"
                                                  : `${v.time_days} روز`,
                                            }),
                                          ],
                                        }),
                                      e.jsx("div", {
                                        className:
                                          "flex items-center justify-between pt-2",
                                        children: e.jsxs("span", {
                                          className:
                                            "text-lg font-bold text-primary",
                                          children: [
                                            (_ = Number(v.price)) == null
                                              ? void 0
                                              : _.toLocaleString("fa-IR"),
                                            " تومان",
                                          ],
                                        }),
                                      }),
                                    ],
                                  }),
                                }),
                              ],
                            }),
                          },
                          v.id,
                        );
                      }),
                    }),
                  ],
                })
              : e.jsxs("div", {
                  className: "text-center py-12 border-2 rounded-2xl",
                  children: [
                    e.jsx(le, {
                      className: "h-12 w-12 text-yellow-400 mx-auto mb-4",
                    }),
                    e.jsx("p", {
                      className: "text-yellow-400 pt-8",
                      children:
                        "هیچ سرویس آماده‌ای یافت نشد. لطفاً از بخش سرویس سفارشی استفاده کنید.",
                    }),
                  ],
                }),
            t.is_custom &&
              e.jsxs(e.Fragment, {
                children: [
                  e.jsx("h3", {
                    className: "text-lg font-semibold mb-4",
                    children: "سرویس سفارشی",
                  }),
                  e.jsxs($, {
                    className: `transition-all ${a ? "ring-2 ring-primary bg-primary/5" : "hover:bg-accent/50"}`,
                    children: [
                      e.jsx(q, {
                        className: "pb-2",
                        children: e.jsxs(G, {
                          className: "text-lg flex items-center gap-2",
                          children: [
                            e.jsx(Je, { className: "h-5 w-5" }),
                            "سرویس سفارشی",
                          ],
                        }),
                      }),
                      e.jsxs(z, {
                        className: "space-y-6",
                        children: [
                          e.jsxs("div", {
                            children: [
                              e.jsxs("label", {
                                className: "text-sm font-medium mb-2 block",
                                children: ["حجم ترافیک: ", m[0], " گیگابایت"],
                              }),
                              e.jsx(ce, {
                                value: m,
                                onValueChange: b,
                                max:
                                  (x == null ? void 0 : x.traffic_max) ?? 1e3,
                                min: (x == null ? void 0 : x.traffic_min) ?? 1,
                                step: 1,
                                className: "w-full",
                              }),
                            ],
                          }),
                          e.jsxs("div", {
                            children: [
                              e.jsxs("label", {
                                className: "text-sm font-medium mb-2 block",
                                children: ["مدت زمان: ", g[0], " روز"],
                              }),
                              e.jsx(ce, {
                                value: g,
                                onValueChange: j,
                                max: (x == null ? void 0 : x.time_max) ?? 365,
                                min: (x == null ? void 0 : x.time_min) ?? 1,
                                step: 1,
                                className: "w-full",
                              }),
                            ],
                          }),
                          e.jsxs("div", {
                            className:
                              "flex items-center justify-between pt-2 border-t",
                            children: [
                              e.jsx("span", {
                                className: "text-lg font-bold",
                                children: "قیمت:",
                              }),
                              w
                                ? e.jsx(K, {
                                    className: "h-5 w-5 animate-spin",
                                  })
                                : x
                                  ? e.jsxs("span", {
                                      className:
                                        "text-lg font-bold text-primary",
                                      children: [
                                        (k = x == null ? void 0 : x.price) ==
                                        null
                                          ? void 0
                                          : k.toLocaleString("fa-IR"),
                                        " تومان",
                                      ],
                                    })
                                  : e.jsx("span", {
                                      className: "text-muted-foreground",
                                      children: "محاسبه نشد",
                                    }),
                            ],
                          }),
                          x &&
                            e.jsx(A, {
                              onClick: R,
                              variant: a ? "default" : "outline",
                              className: "w-full",
                              children: a
                                ? "انتخاب شده"
                                : "انتخاب سرویس سفارشی",
                            }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
            (r || a) &&
              e.jsxs(M.div, {
                initial: { opacity: 0, y: 20 },
                animate: { opacity: 1, y: 0 },
                className:
                  "fixed bottom-24 left-0 right-0 flex justify-around z-10 bg-neutral-200 dark:bg-neutral-700 py-3 my-2 rounded-xl mx-5 items-center",
                children: [
                  e.jsxs("p", {
                    className:
                      "text-center text-sm text-muted-foreground flex flex-col",
                    children: [
                      e.jsx("span", {
                        className: "text-xs text-foreground font-semibold mb-1",
                        children: "سرویس انتخاب شده:",
                      }),
                      e.jsx("span", {
                        className: "font-semibold",
                        children: r
                          ? r.name
                          : a
                            ? `سرویس سفارشی (${a.traffic_gb} گیگابایت, ${a.time_days} روز)`
                            : "هیچ سرویس انتخاب نشده",
                      }),
                    ],
                  }),
                  e.jsx(A, {
                    onClick: i,
                    size: "lg",
                    className:
                      "px-12 shadow-lg hover:shadow-xl transition-shadow",
                    children: "ادامه",
                  }),
                ],
              }),
          ],
        })
  );
}
function Tt({
  selectedCountry: t,
  selectedCategory: s,
  selectedService: n,
  customService: r,
  userBalance: a,
  onPurchaseSuccess: c,
}) {
  const { user: o } = U(),
    [i, u] = l.useState(!1),
    [f, p] = l.useState(null),
    [d, h] = l.useState(""),
    [m, b] = l.useState(""),
    [g, j] = l.useState({}),
    x = n || r,
    S = x ? x.price : 0,
    w = a >= S,
    N = () => {
      const v = {};
      return (
        t.is_username &&
          !d.trim() &&
          (v.username = "نام کاربری سفارشی الزامی است"),
        j(v),
        Object.keys(v).length === 0
      );
    },
    R = async () => {
      var v, C;
      if (!(!(o != null && o.id) || !x) && N()) {
        (u(!0), p(null));
        try {
          const _ = n
              ? {
                  service_id: n.id,
                  custom_username: d.trim(),
                  custom_note: m.trim(),
                  country_id: t.id,
                }
              : {
                  custom_service: {
                    traffic_gb: r.traffic_gb,
                    time_days: r.time_days,
                    category_id: s.id,
                  },
                  country_id: t.id,
                  custom_username: d.trim(),
                  custom_note: m.trim(),
                },
            I = await it(o.id, _);
          I.success && I.service
            ? c(I.service)
            : p(I.message || "خطا در خرید سرویس");
        } catch (_) {
          (console.error("Purchase error:", _),
            typeof _ == "object" &&
            _ !== null &&
            "status" in _ &&
            _.status === 500
              ? p(
                  (typeof _.response == "object" &&
                    _.response &&
                    ((C = (v = _.response) == null ? void 0 : v.data) == null
                      ? void 0
                      : C.msg)) ||
                    "سرویس ساخته نشد. جهت رفع مشکل با پشتیبانی در ارتباط باشید.",
                )
              : p("خطا در ارتباط با سرور"));
        } finally {
          u(!1);
        }
      }
    },
    k = t.is_username || t.is_note;
  return e.jsxs("div", {
    className: "space-y-6",
    children: [
      e.jsxs("div", {
        className: "text-center",
        children: [
          e.jsx("h2", {
            className: "text-2xl font-bold mb-2",
            children: "تأیید خرید",
          }),
          e.jsx("p", {
            className: "text-muted-foreground",
            children: "جزئیات سفارش خود را بررسی کنید",
          }),
        ],
      }),
      e.jsxs("div", {
        className: `grid grid-cols-1 gap-6 ${k ? "lg:grid-cols-3" : "lg:grid-cols-2"}`,
        children: [
          e.jsxs($, {
            children: [
              e.jsx(q, {
                children: e.jsxs(G, {
                  className: "flex items-center gap-2",
                  children: [
                    e.jsx(Ge, { className: "h-5 w-5" }),
                    "خلاصه سفارش",
                  ],
                }),
              }),
              e.jsx(z, {
                className: "space-y-4",
                children: e.jsxs("div", {
                  className: "space-y-2",
                  children: [
                    e.jsxs("div", {
                      className: "flex justify-between",
                      children: [
                        e.jsx("span", {
                          className: "text-muted-foreground",
                          children: "سرویس:",
                        }),
                        e.jsx("span", { children: t.name }),
                      ],
                    }),
                    e.jsxs("div", {
                      className: "flex justify-between",
                      children: [
                        e.jsx("span", {
                          className: "text-muted-foreground",
                          children: "دسته‌بندی:",
                        }),
                        e.jsx("span", { children: s.name }),
                      ],
                    }),
                    n
                      ? e.jsxs(e.Fragment, {
                          children: [
                            e.jsxs("div", {
                              className: "flex justify-between",
                              children: [
                                e.jsx("span", {
                                  className: "text-muted-foreground",
                                  children: "سرویس:",
                                }),
                                e.jsx("span", { children: n.name }),
                              ],
                            }),
                            n.traffic_gb &&
                              e.jsxs("div", {
                                className: "flex justify-between",
                                children: [
                                  e.jsx("span", {
                                    className: "text-muted-foreground",
                                    children: "ترافیک:",
                                  }),
                                  e.jsxs("span", {
                                    children: [n.traffic_gb, " گیگابایت"],
                                  }),
                                ],
                              }),
                            n.time_days &&
                              e.jsxs("div", {
                                className: "flex justify-between",
                                children: [
                                  e.jsx("span", {
                                    className: "text-muted-foreground",
                                    children: "مدت زمان:",
                                  }),
                                  e.jsxs("span", {
                                    children: [n.time_days, " روز"],
                                  }),
                                ],
                              }),
                          ],
                        })
                      : r
                        ? e.jsxs(e.Fragment, {
                            children: [
                              e.jsxs("div", {
                                className: "flex justify-between",
                                children: [
                                  e.jsx("span", {
                                    className: "text-muted-foreground",
                                    children: "سرویس:",
                                  }),
                                  e.jsx("span", { children: "سرویس سفارشی" }),
                                ],
                              }),
                              e.jsxs("div", {
                                className: "flex justify-between",
                                children: [
                                  e.jsx("span", {
                                    className: "text-muted-foreground",
                                    children: "ترافیک:",
                                  }),
                                  e.jsxs("span", {
                                    children: [r.traffic_gb, " گیگابایت"],
                                  }),
                                ],
                              }),
                              e.jsxs("div", {
                                className: "flex justify-between",
                                children: [
                                  e.jsx("span", {
                                    className: "text-muted-foreground",
                                    children: "مدت زمان:",
                                  }),
                                  e.jsxs("span", {
                                    children: [r.time_days, " روز"],
                                  }),
                                ],
                              }),
                            ],
                          })
                        : null,
                    e.jsxs("div", {
                      className:
                        "flex justify-between font-bold text-lg pt-2 border-t",
                      children: [
                        e.jsx("span", { children: "قیمت کل:" }),
                        e.jsxs("span", {
                          className: "text-primary",
                          children: [
                            Number(S).toLocaleString("fa-IR"),
                            " تومان",
                          ],
                        }),
                      ],
                    }),
                  ],
                }),
              }),
            ],
          }),
          k &&
            e.jsxs($, {
              children: [
                e.jsx(q, {
                  children: e.jsxs(G, {
                    className: "flex items-center gap-2",
                    children: [
                      e.jsx(Ie, { className: "h-5 w-5" }),
                      "تنظیمات سفارشی",
                    ],
                  }),
                }),
                e.jsxs(z, {
                  className: "space-y-4",
                  children: [
                    t.is_username &&
                      e.jsxs("div", {
                        className: "space-y-2",
                        children: [
                          e.jsxs("label", {
                            className: "text-sm font-medium",
                            children: [
                              "نام کاربری سفارشی ",
                              e.jsx("span", {
                                className: "text-red-500",
                                children: "*",
                              }),
                            ],
                          }),
                          e.jsx(oe, {
                            type: "text",
                            placeholder: "نام کاربری مورد نظر خود را وارد کنید",
                            value: d,
                            onChange: (v) => {
                              (h(v.target.value),
                                g.username &&
                                  j((C) => ({ ...C, username: void 0 })));
                            },
                            className: g.username
                              ? "border-red-500 mt-2.5"
                              : "mt-2.5",
                          }),
                          g.username &&
                            e.jsx("p", {
                              className: "text-sm text-red-500",
                              children: g.username,
                            }),
                        ],
                      }),
                    t.is_note &&
                      e.jsxs("div", {
                        className: "space-y-2",
                        children: [
                          e.jsx("label", {
                            className: "text-sm font-medium",
                            children: "یادداشت (اختیاری)",
                          }),
                          e.jsx(oe, {
                            type: "text",
                            className: "mt-2.5",
                            placeholder: "یادداشت خود را وارد کنید",
                            value: m,
                            onChange: (v) => b(v.target.value),
                          }),
                        ],
                      }),
                  ],
                }),
              ],
            }),
          e.jsxs($, {
            children: [
              e.jsx(q, {
                children: e.jsxs(G, {
                  className: "flex items-center gap-2",
                  children: [
                    e.jsx(Ze, { className: "h-5 w-5" }),
                    "اطلاعات پرداخت",
                  ],
                }),
              }),
              e.jsxs(z, {
                className: "space-y-4",
                children: [
                  e.jsxs("div", {
                    className: "space-y-2",
                    children: [
                      e.jsxs("div", {
                        className: "flex justify-between",
                        children: [
                          e.jsx("span", {
                            className: "text-muted-foreground",
                            children: "موجودی کیف پول:",
                          }),
                          e.jsxs("span", {
                            className:
                              a > 0 ? "text-green-600" : "text-red-600",
                            children: [a.toLocaleString("fa-IR"), " تومان"],
                          }),
                        ],
                      }),
                      e.jsxs("div", {
                        className: "flex justify-between",
                        children: [
                          e.jsx("span", {
                            className: "text-muted-foreground",
                            children: "مبلغ قابل پرداخت:",
                          }),
                          e.jsxs("span", {
                            className: "text-primary",
                            children: [
                              Number(S).toLocaleString("fa-IR"),
                              " تومان",
                            ],
                          }),
                        ],
                      }),
                      e.jsxs("div", {
                        className:
                          "flex justify-between font-bold pt-2 border-t",
                        children: [
                          e.jsx("span", { children: "باقی‌مانده:" }),
                          e.jsxs("span", {
                            className: w ? "text-green-600" : "text-red-600",
                            children: [
                              (a - S).toLocaleString("fa-IR"),
                              " تومان",
                            ],
                          }),
                        ],
                      }),
                    ],
                  }),
                  !w &&
                    e.jsxs("div", {
                      className:
                        "bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-400 p-3 rounded-md flex items-center gap-2",
                      children: [
                        e.jsx(Le, { className: "h-4 w-4" }),
                        e.jsx("span", {
                          className: "text-sm",
                          children:
                            "موجودی کیف پول شما کافی نیست. لطفاً ابتدا کیف پول خود را شارژ کنید.",
                        }),
                      ],
                    }),
                  f &&
                    e.jsx("div", {
                      className:
                        "bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-400 p-3 rounded-md",
                      children: e.jsx("span", {
                        className: "text-sm",
                        children: f,
                      }),
                    }),
                  e.jsx(A, {
                    onClick: R,
                    disabled: !w || i,
                    className: "w-full",
                    size: "lg",
                    children: i
                      ? e.jsxs(e.Fragment, {
                          children: [
                            e.jsx(K, {
                              className: "h-4 w-4 animate-spin ml-2",
                            }),
                            "در حال پردازش...",
                          ],
                        })
                      : "تأیید و پرداخت",
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
function Vt({ service: t, onStartNewPurchase: s }) {
  const n = Ee(),
    r = (a) => {
      switch (a == null ? void 0 : a.toLowerCase()) {
        case "active":
          return "bg-green-500";
        case "on_hold":
          return "bg-purple-500";
        case "limited":
          return "bg-red-500";
        case "expired":
          return "bg-yellow-500";
        case "disabled":
          return "bg-gray-500";
        default:
          return "bg-gray-500";
      }
    };
  return e.jsxs("div", {
    className: "space-y-6",
    children: [
      e.jsxs(M.div, {
        initial: { scale: 0.8, opacity: 0 },
        animate: { scale: 1, opacity: 1 },
        transition: { duration: 0.5 },
        className: "text-center",
        children: [
          e.jsx("div", {
            className:
              "bg-green-100 dark:bg-green-900/20 text-green-600 dark:text-green-400 p-4 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center",
            children: e.jsx(Oe, { size: 48 }),
          }),
          e.jsx("h2", {
            className: "text-2xl font-bold mb-2",
            children: "خرید با موفقیت انجام شد!",
          }),
          e.jsx("p", {
            className: "text-muted-foreground",
            children: "سرویس‌ شما با موفقیت خریداری شد",
          }),
        ],
      }),
      e.jsxs("div", {
        className: "space-y-4",
        children: [
          e.jsx("h3", {
            className: "text-lg font-semibold",
            children: "سرویس‌ خریداری شده:",
          }),
          e.jsx(
            M.div,
            {
              initial: { opacity: 0, y: 20 },
              animate: { opacity: 1, y: 0 },
              transition: { duration: 0.3, delay: 0.1 },
              children: e.jsx($, {
                children: e.jsx(z, {
                  className: "p-4",
                  children: e.jsxs("div", {
                    className: "flex items-center justify-between",
                    children: [
                      e.jsxs("div", {
                        className: "flex items-center gap-3",
                        children: [
                          e.jsxs("div", {
                            className:
                              "relative h-10 w-10 flex items-center justify-center bg-neutral-100 dark:bg-neutral-800 rounded-full",
                            children: [
                              e.jsx("div", {
                                className: `absolute -top-1 -left-1 h-3 w-3 rounded-full ${r(t.status)}`,
                                children: e.jsx("span", {
                                  className: `absolute inset-0 rounded-full ${r(t.status)} animate-ping opacity-75`,
                                }),
                              }),
                              e.jsx("span", {
                                className: "text-lg font-semibold",
                                children: t.username.charAt(0).toUpperCase(),
                              }),
                            ],
                          }),
                          e.jsxs("div", {
                            className: "text-right",
                            children: [
                              e.jsx("h4", {
                                className: "font-bold",
                                children: t.username,
                              }),
                              e.jsxs("p", {
                                className: "text-sm text-muted-foreground",
                                children: ["تاریخ انقضا: ", t.expire],
                              }),
                            ],
                          }),
                        ],
                      }),
                      e.jsx("div", {
                        className: "flex items-center gap-2",
                        children: e.jsx(A, {
                          variant: "outline",
                          size: "sm",
                          onClick: () => n(`/services/${t.username}`),
                          children: "دریافت سرویس",
                        }),
                      }),
                    ],
                  }),
                }),
              }),
            },
            t.id,
          ),
          e.jsx("p", {
            className: "text-yellow-400 text-center text-sm",
            children:
              "برای مشاهده سرویس خریداری شده بر روی دکمه دریافت سرویس کلیک کنید",
          }),
        ],
      }),
      e.jsxs("div", {
        className: "flex flex-col sm:flex-row gap-4 justify-center",
        children: [
          e.jsx(A, {
            onClick: () => n("/services"),
            variant: "outline",
            size: "lg",
            children: "مشاهده همه سرویس‌ها",
          }),
          e.jsx(A, { onClick: s, size: "lg", children: "خرید سرویس جدید" }),
        ],
      }),
    ],
  });
}
const de = [
  {
    id: 1,
    title: "انتخاب دسته‌بندی",
    description: "دسته‌بندی مورد نظر را انتخاب کنید",
  },
  { id: 2, title: "انتخاب سرویس", description: "سرویس مورد نظر را انتخاب کنید" },
  { id: 3, title: "انتخاب مدت زمان", description: "بازه زمانی را تعیین کنید" },
  {
    id: 4,
    title: "انتخاب پلن",
    description: "پلن مورد نظر را انتخاب کنید",
  },
  { id: 5, title: "تأیید خرید", description: "جزئیات سفارش را بررسی کنید" },
  { id: 6, title: "تکمیل خرید", description: "خرید با موفقیت انجام شد" },
];
function Zt() {
  const { user: t } = U(),
    [s, n] = l.useState(1),
    [r, a] = l.useState(0),
    [c, o] = l.useState(new Set()),
    [i, u] = l.useState(null),
    [f, p] = l.useState(null),
    [d, h] = l.useState(null),
    [m, b] = l.useState(null),
    [g, j] = l.useState(null),
    [x, S] = l.useState({ id: "", username: "", status: "", expire: "" });
  l.useEffect(() => {
    (async () => {
      if (t != null && t.id)
        try {
          const P = await ie(t.id);
          a(P.obj.balance);
        } catch (P) {
          console.error("Error fetching user balance:", P);
        }
    })();
  }, [t == null ? void 0 : t.id]);
  const w = (y) => {
      c.has(y) || ((y < s || N(y)) && n(y));
    },
    N = (y) => {
      if (c.has(y)) return !1;
      switch (y) {
        case 1:
          return !0;
        case 2:
          return !!f;
        case 3:
          return !!i && !!f;
        case 4:
          return !!i && !!f && !!d;
        case 5:
          return !!i && !!f && !!d && (!!m || !!g);
        case 6:
          return x.id !== "";
        default:
          return !1;
      }
    },
    R = () => {
      if (s === 6) return !1;
      for (let y = s - 1; y >= 1; y--) if (!c.has(y)) return !0;
      return !1;
    },
    k = () => {
      for (let y = s - 1; y >= 1; y--)
        if (!c.has(y)) {
          n(y);
          return;
        }
    },
    v = (y) => {
      (o((P) => new Set(P).add(y)), n(y + 1));
    },
    C = () => {
      s < de.length && n(s + 1);
    },
    _ = () => {
      (n(1),
        o(new Set()),
        u(null),
        p(null),
        h(null),
        b(null),
        j(null),
        S({ id: "", username: "", status: "", expire: "" }));
    },
    I = (y) => {
      (u(y),
        o((P) => {
          const q = new Set(P);
          return (q.delete(3), q.delete(4), q);
        }),
        h(null),
        b(null),
        j(null));
    },
    E = (y) => {
      (p(y),
        o((P) => {
          const q = new Set(P);
          return (q.delete(2), q.delete(3), q.delete(4), q);
        }),
        u(null),
        h(null),
        b(null),
        j(null));
    },
    D = (y) => {
      (h(y), b(null), j(null));
    },
    T = (y) => {
      (b(y), j(null));
    },
    Z = (y) => {
      (j(y), b(null));
    },
    Y = (y) => {
      (S(y),
        n(6),
        ie(t == null ? void 0 : t.id)
          .then((P) => {
            a(P.obj.balance);
          })
          .catch(console.error));
    },
    B = () => {
      switch (s) {
        case 1:
          return e.jsx(lt, {
            selectedCategory: f,
            onCategorySelect: E,
            onNext: C,
            onStepSkipped: () => v(1),
          });
        case 2:
          return f
            ? e.jsx(ot, {
                selectedCountry: i,
                selectedCategory: f,
                onCountrySelect: I,
                onNext: C,
                onStepSkipped: () => v(2),
              })
            : null;
        case 3:
          return i && f
            ? e.jsx(ct, {
                selectedCountry: i,
                selectedCategory: f,
                selectedTimeRange: d,
                onTimeRangeSelect: D,
                onNext: C,
                onStepSkipped: () => v(3),
              })
            : null;
        case 4:
          return i && f && d
            ? e.jsx(Lt, {
                selectedCountry: i,
                selectedCategory: f,
                selectedTimeRange: d,
                selectedService: m,
                customService: g,
                onServiceSelect: T,
                onCustomServiceSelect: Z,
                onNext: C,
              })
            : null;
        case 5:
          return i && f && (m || g)
            ? e.jsx(Tt, {
                selectedCountry: i,
                selectedCategory: f,
                selectedService: m,
                customService: g,
                userBalance: r,
                onPurchaseSuccess: Y,
              })
            : null;
        case 6:
          return e.jsx(Vt, { service: x, onStartNewPurchase: _ });
        default:
          return null;
      }
    };
  return e.jsx(Pe, {
    children: e.jsxs("div", {
      className: "container mx-auto px-4 py-8 mb-24 font-vazir",
      children: [
        e.jsx("h1", {
          className: "text-4xl font-bold mb-8 text-center",
          children: "خرید سرویس",
        }),
        e.jsx(et, {
          steps: de,
          currentStep: s,
          skippedSteps: c,
          onStepClick: w,
          canGoBack: R(),
          onGoBack: k,
        }),
        e.jsx("div", { className: "max-w-4xl mx-auto", children: B() }),
      ],
    }),
  });
}
export { Zt as default };
